import os
import smtplib
import traceback
import configparser
import time
import random
import re
from colorama import init, Fore
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

# set color for input messages
input_color = Fore.YELLOW
input_color2 = Fore.GREEN

# activate colorama
init()

# get the current date and time
current_time = datetime.now()

# welcome message
message = """
 _____                              _____                _           
|  ___|                            /  ___|              | |          
| |__ _ __  _______  ___   ______  \ `--.  ___ _ __   __| | ___ _ __ 
|  __| '_ \|_  / _ \/ __| |______|  `--. \/ _ \ '_ \ / _` |/ _ \ '__|
| |__| | | |/ / (_) \__ \          /\__/ /  __/ | | | (_| |  __/ |   
\____/_| |_/___\___/|___/          \____/ \___|_| |_|\__,_|\___|_|   
                                                                     
                    @Caesar_A1 on Telegram                           \n \n \n
"""

# Iterate through each character in the message and print it out with a delay
for char in message:
    print(Fore.LIGHTBLUE_EX + char + Fore.RESET, end="", flush=True)
    time.sleep(0.0025)  # adjust the delay time to your liking


# get required inputs from user with error handling
while True:
    receiver_list = input(input_color + " ═ Enter the file name of the recipients list: " + Fore.RESET)
    if not os.path.exists(receiver_list):
        print(Fore.RED + f"Error: {receiver_list} does not exist." + Fore.RESET)
    elif not os.path.isfile(receiver_list):
        print(Fore.RED + f"Error: {receiver_list} is not a file." + Fore.RESET)
    else:
        break

while True:
    spoofed_email = input(input_color + " ═ Enter the spoofed email address: " + Fore.RESET)
    if not re.match(r"[^@]+@[^@]+\.[^@]+", spoofed_email):
        print(Fore.RED + f"Error: {spoofed_email} is not a valid email address." + Fore.RESET)
    else:
        break

while True:
    spoofed_name = input(input_color + " ═ Enter the spoofed name: " + Fore.RESET)
    if not spoofed_name:
        print(Fore.RED + "Error: Spoofed name cannot be empty." + Fore.RESET)
    else:
        break

while True:
    subject = input(input_color + " ═ Enter the subject of the email: " + Fore.RESET)
    if not subject:
        print(Fore.RED + "Error: Subject cannot be empty." + Fore.RESET)
    else:
        break

while True:
    letter_format = input(input_color + " ═ Enter the format of the letter (plain or html): " + Fore.RESET).lower()
    if letter_format not in ["plain", "html"]:
        print(Fore.RED + "Error: Letter format must be either 'plain' or 'html'." + Fore.RESET)
    else:
        break

letter_path = input(input_color + " ═ Enter the path to the letter file: " + Fore.RESET)

while True:
    attachment_path = input(input_color + " = Enter the path to attachment file (leave empty if none): " + Fore.RESET)
    if attachment_path and (not os.path.exists(attachment_path) or not os.path.isfile(attachment_path)):
        print(Fore.RED + f"Error: {attachment_path} is not a valid file path." + Fore.RESET)
    else:
        break

print("\n\n")
# read SMTP settings from config file
config = configparser.ConfigParser()
config.read('config.ini')
smtp_host = config.get('SMTP', 'host')
smtp_port = config.getint('SMTP', 'port')
smtp_username = config.get('SMTP', 'username')
smtp_password = config.get('SMTP', 'password')

def send_mail(receiver_email, spoofed_email, spoofed_name, message, subject, attachment_path=None):
    try:
        msg = MIMEMultipart("related")
        msg['From'] = f"{spoofed_name} <{spoofed_email}>"
        msg['To'] = receiver_email
        msg['Subject'] = subject
        body = message.replace('##email##', receiver_email).replace('##time##', time.strftime('%c'))
        if '##link##' in body:
            with open('urls.txt', 'r') as urls_file:
                urls = urls_file.read().splitlines()
            link = random.choice(urls)
            body = body.replace('##link##', link)
        body = re.sub(r'##edomain##', receiver_email.split('@')[1], body) # replaces ##edomain## with recipient's email domain
        
        # Replace ##rsix## tag with a randomly generated 6-digit number
        rsix_regex = r'##rsix##'
        rsix = str(random.randint(100000, 999999))
        body = re.sub(rsix_regex, rsix, body)
        
        if letter_format == "html":
            msg.attach(MIMEText(body, 'html'))
        else:
            msg.attach(MIMEText(body, 'plain'))


        if attachment_path:
            with open(attachment_path, 'rb') as attachment:
                attachment_contents = attachment.read()

            # replace the placeholder text '##useremail##' with the recipient's email address
            attachment_contents = attachment_contents.replace(b'##useremail##', bytes(receiver_email, 'utf-8'))

            # attach the modified HTML file to the message
            attachment = MIMEBase('application', 'octet-stream')
            attachment.set_payload(attachment_contents)
            encoders.encode_base64(attachment)
            attachment.add_header('Content-Disposition', f'attachment; filename="{os.path.basename(attachment_path)}"')
            msg.attach(attachment)

        # Get SMTP settings from config file
        smtp_host = config.get('SMTP', 'host')
        smtp_port = config.getint('SMTP', 'port')
        smtp_username = config.get('SMTP', 'username')
        smtp_password = config.get('SMTP', 'password')

        # Connect to SMTP server and send email
        server = smtplib.SMTP(smtp_host, smtp_port)
        server.starttls()
        server.login(smtp_username, smtp_password)
        text = msg.as_string()
        server.sendmail(spoofed_email, receiver_email, text)
        server.quit()
        print('\n' + input_color2 + ' + Spoofed Email sent successfully to ' + str(receiver_email) + ' from ' + str(spoofed_name) + ' on ' + current_time.strftime('%Y-%m-%d %H:%M:%S') + Fore.RESET)
    except Exception as e:
        # Print the exception
        print(traceback.format_exc())

with open(receiver_list, 'r', encoding='utf-8') as f:
    receiver_emails = f.read().splitlines()

# loop through all the email addresses and send the email
for receiver_email in receiver_emails:
    message = ''
    with open(letter_path, 'r', encoding='latin-1') as letter:
        message = letter.read()
    send_mail(receiver_email, spoofed_email, spoofed_name, message, subject, attachment_path)
    time.sleep(75) # wait for 2 minutes